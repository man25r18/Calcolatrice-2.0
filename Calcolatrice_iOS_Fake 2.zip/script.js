
let display = document.getElementById('display');
let sciButtons = document.getElementById('sci-buttons');
let fakeResult = null;

function press(value) {
    if (display.innerText === '0' || display.innerText === fakeResult) {
        display.innerText = value;
    } else {
        display.innerText += value;
    }
}

function clearDisplay() {
    display.innerText = '0';
}

function calculate() {
    const text = display.innerText.trim();
    if (/^=\d+=?$/.test(text)) {
        // set fake result mode
        fakeResult = text.replace(/=/g, '');
        display.innerText = 'Risultato impostato';
    } else {
        try {
            let result = eval(display.innerText);
            if (fakeResult !== null) {
                display.innerText = fakeResult;
                fakeResult = null;
            } else {
                display.innerText = result;
            }
        } catch {
            display.innerText = 'Errore';
        }
    }
}

function toggleScientific() {
    sciButtons.classList.toggle('hidden');
}
