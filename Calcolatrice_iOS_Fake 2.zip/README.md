
# Calcolatrice iOS Simulata

Questa è una calcolatrice web con interfaccia ispirata a quella di iOS, pubblicata su GitHub Pages.

## Funzioni principali
- Modalità base e scientifica (toccando il display)
- Possibilità di impostare un risultato personalizzato digitando `=999=`
- Responsive e pronta per dispositivi mobili

## Come usarla
1. Tocca il display per passare da modalità base a scientifica.
2. Premi `=1234=` per impostare un risultato finto.
3. Qualsiasi operazione successiva mostrerà quel risultato.
